function createToliaPiano() {
  const AudioEngine = window.AudioContext || window.webkitAudioContext;
  let audio, output, sample, track;
  let audible = true;
  let generation = 0;

  // D major, with the same little melody returning over different inversions.
  const chords = [
    [50, 57, 62, 66, 69], [45, 57, 61, 64, 69],
    [47, 54, 59, 62, 66], [43, 55, 59, 62, 66],
    [42, 54, 57, 62, 66], [47, 54, 59, 62, 69],
    [43, 50, 59, 62, 67], [45, 52, 57, 61, 64],
  ];
  const melody = [
    [69, 73, 74], [76, 73, 69], [66, 69, 74], [71, 69, 66],
    [69, 66, 64], [66, 69, 71], [74, 71, 67], [69, 64, 61],
  ];

  function makeSample() {
    const seconds = 3.4;
    const length = Math.round(audio.sampleRate * seconds);
    const buffer = audio.createBuffer(1, length, audio.sampleRate);
    const wave = buffer.getChannelData(0);
    const partials = [[1, .69, 1.05], [2.002, .21, .49], [3.009, .13, .29], [4.022, .057, .19], [5.04, .027, .11], [6.07, .016, .076]];
    const frequency = 261.6256;
    for (let i = 0; i < length; i++) {
      const t = i / audio.sampleRate;
      const phase = 2 * Math.PI * frequency * t;
      let value = 0;
      for (const [ratio, gain, decay] of partials) {
        value += gain * Math.exp(-t / decay) * Math.sin(phase * ratio);
      }
      const attack = Math.min(1, t / .006);
      const tail = Math.min(1, (seconds - t) / .18);
      wave[i] = value * attack * tail * (.94 + .06 * Math.cos(t * 13));
    }
    return buffer;
  }

  function note(bus, at, pitch, velocity) {
    const key = audio.createBufferSource();
    const level = audio.createGain();
    key.buffer = sample;
    key.playbackRate.value = 2 ** ((pitch - 60) / 12);
    level.gain.value = velocity;
    key.connect(level).connect(bus);
    key.start(at);
    track.keys.push(key);
  }

  function stop() {
    generation++;
    if (track) {
      track.bus.disconnect();
      for (const key of track.keys) key.stop();
      track = null;
    }
  }

  async function play(duration) {
    if (!AudioEngine) return;
    stop();
    const revision = generation;
    try {
      if (!audio) {
        audio = new AudioEngine();
        output = audio.createGain();
        output.gain.value = audible ? .23 : 0;
        output.connect(audio.destination);
      }
      await audio.resume();
      if (revision !== generation) return;
      sample ??= makeSample();
      const bus = audio.createGain();
      bus.connect(output);
      track = { bus, keys: [] };
      const start = audio.currentTime + .035;
      const bars = 56;
      const beat = (duration - 3.5) / (bars * 4);
      bus.gain.setValueAtTime(.0001, start);
      bus.gain.linearRampToValueAtTime(1, start + .65);
      bus.gain.setValueAtTime(1, start + duration - 3);
      bus.gain.linearRampToValueAtTime(0, start + duration);
      for (let bar = 0; bar < bars; bar++) {
        const at = start + bar * beat * 4;
        const index = bar % chords.length;
        const chord = chords[index];
        const phrase = Math.floor(bar / chords.length);
        note(bus, at, chord[0], .26);
        const order = phrase % 2 ? [1, 3, 2, 4, 3] : [1, 2, 3, 4, 2];
        order.forEach((key, i) => note(bus, at + beat * (.5 + .62 * i), chord[key], .15 + i % 2 * .018));
        if (bar >= 3 && bar % 8 !== 7) {
          melody[index].forEach((pitch, i) => {
            if (phrase === 0 && i === 1) return;
            note(bus, at + beat * (.78 + i * 1.1), pitch, i === 0 ? .23 : .19);
          });
        }
      }
      [50, 57, 62, 66, 74].forEach((pitch, i) => note(bus, start + duration - 3.5 + i * .045, pitch, .24 - i * .019));
    } catch {
      // Playback may be blocked by the device. The story can continue silently.
    }
  }

  function setAudible(enabled) {
    audible = enabled;
    if (output) output.gain.setTargetAtTime(enabled ? .23 : 0, audio.currentTime, .12);
  }

  return { play, stop, setAudible };
}
